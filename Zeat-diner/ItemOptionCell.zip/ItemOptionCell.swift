
import UIKit
import Eureka

public struct Option: Equatable {
    var name: String
    var price: Float
}

public func ==(lhs: Option, rhs: Option) -> Bool {
    return lhs.name == rhs.name
}




public class ItemOptionCell : Cell<Option>, CellType {
    
    @IBOutlet weak var selectImage: UIImageView!
    
    @IBOutlet weak var optionName: UILabel!
    @IBOutlet weak var optionPrice: UILabel!
    
    required public init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    public var trueImage: UIImage = {
        return #imageLiteral(resourceName: "selectedCheckBox")
    }()
    
    public var falseImage: UIImage = {
        return #imageLiteral(resourceName: "unselectedCheckBox")
    }()
    
    
    open override func setup() {
        super.setup()
    }
    
    open override func update() {
        super.update()
        accessoryType = .none
        selectImage?.image = row.value != nil ? trueImage : falseImage
        
        
    }
    
    public override func didSelect() {
        row.reload()
        row.select()
        row.deselect()
    }
    
    
}

public final class ItemOptionRow: Row<ItemOptionCell>, SelectableRowType,  RowType {
    public var selectableValue: Option?
    
    required public init(tag: String?) {
        super.init(tag: tag)
        displayValueFor = nil
        cellProvider = CellProvider<ItemOptionCell>(nibName: "ItemOptionCell")
    }
}

